package com.fsd9.ecom.common.constants;

public enum RoleEnum {
    ROLE_ADMIN,
    ROLE_USER,
    ROLE_SUPPLIER,
    ROLE_SUPPORT_USER
}
